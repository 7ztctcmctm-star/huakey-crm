const maskPhone = (phone) => {
  if (!phone) return '';
  const str = String(phone);
  if (str.length >= 7) {
    return str.substring(0, 3) + '****' + str.substring(str.length - 4);
  }
  return '****';
};

const maskEmail = (email) => {
  if (!email) return '';
  const [local, domain] = email.split('@');
  if (!domain) return '****@****.***';
  const maskedLocal = local.length > 2 
    ? local[0] + '***' + local[local.length - 1]
    : '***';
  return maskedLocal + '@' + domain;
};

const maskIdCard = (idCard) => {
  if (!idCard) return '';
  const str = String(idCard);
  if (str.length >= 8) {
    return str.substring(0, 4) + '**********' + str.substring(str.length - 4);
  }
  return '**********';
};

const maskBankCard = (cardNo) => {
  if (!cardNo) return '';
  const str = String(cardNo).replace(/\s/g, '');
  if (str.length > 4) {
    return '**** **** **** ' + str.substring(str.length - 4);
  }
  return '**** **** **** ****';
};

const maskName = (name) => {
  if (!name) return '';
  const str = String(name).trim();
  if (str.length <= 1) return '*';
  if (str.length === 2) return str[0] + '*';
  return str[0] + '*'.repeat(str.length - 2) + str[str.length - 1];
};

const maskSensitiveData = (data, fields = []) => {
  if (!data || !Array.isArray(fields)) return data;
  
  const result = { ...data };
  
  for (const field of fields) {
    if (result[field]) {
      switch (field.toLowerCase()) {
        case 'phone':
        case 'mobile':
        case 'telephone':
          result[field] = maskPhone(result[field]);
          break;
        case 'email':
          result[field] = maskEmail(result[field]);
          break;
        case 'id_card':
        case 'idcard':
          result[field] = maskIdCard(result[field]);
          break;
        case 'bank_card':
        case 'bankcard':
        case 'account_no':
          result[field] = maskBankCard(result[field]);
          break;
        case 'password':
        case 'pwd':
          delete result[field];
          break;
      }
    }
  }
  
  return result;
};

// 日志脱敏：自动识别常见敏感字段并脱敏
const SENSITIVE_FIELDS = {
  password: '******',
  old_password: '******',
  new_password: '******',
  confirm_password: '******',
  pwd: '******'
};

const MASK_FIELDS = ['phone', 'mobile', 'telephone', 'email', 'id_card', 'idcard', 'bank_card', 'bankcard', 'account_no'];

function maskLogParams(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  const result = Array.isArray(obj) ? [...obj] : { ...obj };

  for (const key of Object.keys(result)) {
    const lowerKey = key.toLowerCase();

    // 密码类字段：直接替换
    if (lowerKey in SENSITIVE_FIELDS) {
      result[key] = SENSITIVE_FIELDS[lowerKey];
      continue;
    }

    // 其他敏感字段：部分脱敏
    if (MASK_FIELDS.includes(lowerKey)) {
      result[key] = maskSensitiveData({ [key]: result[key] }, [key])[key];
      continue;
    }

    // 嵌套对象：递归处理
    if (result[key] && typeof result[key] === 'object' && !(result[key] instanceof Date)) {
      result[key] = maskLogParams(result[key]);
    }
  }

  return result;
}

module.exports = {
  maskPhone,
  maskEmail,
  maskIdCard,
  maskBankCard,
  maskName,
  maskSensitiveData,
  maskLogParams
};
